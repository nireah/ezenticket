package com.ezen_ticket.member.mapper;

import com.ezen_ticket.member.vo.LoginVO;

public interface MemberMapper {

	public LoginVO login(LoginVO vo);
	
}
