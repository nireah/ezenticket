package com.ezen_ticket.member.service;

import com.ezen_ticket.member.vo.LoginVO;

public interface MemberService {

	public LoginVO login(LoginVO vo);
	
}
